package com.anis.unss;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;

/** Restores scheduled prayer alarms after the device finishes booting. */
public class AdhanBootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null || !Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        try {
            String saved = context.getSharedPreferences("anis_adhan", Context.MODE_PRIVATE).getString("alarms", "[]");
            JSONArray alarms = new JSONArray(saved);
            AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            long now = System.currentTimeMillis();
            for (int i = 0; i < alarms.length(); i++) {
                JSONObject item = alarms.getJSONObject(i);
                long at = item.optLong("at", 0L);
                if (at <= now) continue;
                int id = item.optInt("id", 0);
                String prayer = item.optString("prayer", "الصلاة");
                Intent alarm = new Intent(context, AdhanAlarmReceiver.class);
                alarm.putExtra("prayer", prayer);
                int flags = PendingIntent.FLAG_UPDATE_CURRENT;
                if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
                PendingIntent pi = PendingIntent.getBroadcast(context, id, alarm, flags);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    try { manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi); }
                    catch (SecurityException denied) { manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi); }
                } else manager.setExact(AlarmManager.RTC_WAKEUP, at, pi);
            }
        } catch (Exception ignored) { }
    }
}
